/*
 * libc.c 
 */

#include <libc.h>

#include <types.h>

#include <errno.h>

int errno = 0;

void perror(void) {
  char errnoCode[16];
  switch(errno)
  {
    case EINVAL:
      write(1,"\nEINVAL: Invalid Argument\n",27);
      break;
    case EFAULT:
      write(1,"\nEFAULT: Bad Adress\n",21);
      break;
    case ENOSYS:
      write(1,"\nENOSYS: Syscall Not Implemented",33);
      break;
    case EACCES:
      write(1,"\nEACCES: Permission Denied\n",28);
      break;
    case EBADF:
      write(1,"\nEBADF: Bad file number\n",25);
      break;
    default:
      itoa(errno, errnoCode);
      write(1, "Message for error ", 18);
      write(1, errnoCode, strlen (errnoCode));
      write(1, " not found\n", 11);
  }
}

void itoa(int a, char *b)
{
  int i, i1;
  char c;
  
  if (a==0) { b[0]='0'; b[1]=0; return ;}
  
  i=0;
  while (a>0)
  {
    b[i]=(a%10)+'0';
    a=a/10;
    i++;
  }
  
  for (i1=0; i1<i/2; i1++)
  {
    c=b[i1];
    b[i1]=b[i-i1-1];
    b[i-i1-1]=c;
  }
  b[i]=0;
}

int strlen(char *a)
{
  int i;
  
  i=0;
  
  while (a[i]!=0) i++;
  
  return i;
}

